package com.hca.soda.vendingmachine.service;

import java.math.BigDecimal;
import java.util.List;
import com.hca.soda.vendingmachine.model.Snack;

/**
 * @author Vara
 */
public interface VendingMachineService {
    
	public void addMoney(String amount);
    
    public void makePurchase();
    
    public void changeReturn();

    BigDecimal getBalance();

    String getMessage();

    Change getChange();

    int getSelection();

    Snack getSnackById(int id);

    List<Snack> getSnacks();

    void setBalance(BigDecimal balance);

    void setMessage(String message);

    void setMyChange(Change myChange);

    void setSelection(int Selection);    
}


