package com.hca.soda.vendingmachine.dao;

import com.hca.soda.vendingmachine.model.Snack;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Vara
 */
public class VendingMachineDAOImpl implements VendingMachineDAO {
    HashMap<Integer,Snack> snacks;
    
    public VendingMachineDAOImpl() {
        snacks = new HashMap<>();
        snacks.put(1, new Snack(1,"THUMSUP",new BigDecimal("2.25"),10));
        snacks.put(2, new Snack(2,"COCACOLA",new BigDecimal("2.10"),12));
        snacks.put(3, new Snack(3,"PEPSI",new BigDecimal("1.70"),15));       
    }

    @Override
    public Snack getSnackById(int id) {
        return snacks.get(id);
    }

    @Override
    public List<Snack> getSnacks() {
        return new ArrayList<>(snacks.values());
    }
    
}

