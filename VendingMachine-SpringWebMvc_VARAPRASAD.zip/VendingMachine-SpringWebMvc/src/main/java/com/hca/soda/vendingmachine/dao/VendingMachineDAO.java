package com.hca.soda.vendingmachine.dao;

import com.hca.soda.vendingmachine.model.Snack;
import java.util.List;

/**
 *
 * @author Vara
 */
public interface VendingMachineDAO {
    public Snack getSnackById(int id);
    public List<Snack> getSnacks();
}
