package com.hca.soda.vendingmachine.service;

import java.math.BigDecimal;
import java.util.List;
import javax.inject.Inject;
import com.hca.soda.vendingmachine.model.Snack;
import com.hca.soda.vendingmachine.dao.VendingMachineDAO;

/**
 * @author Vara
 */
public class VendingMachineServiceImpl implements VendingMachineService {
    private VendingMachineDAO vendingMachineDAO;
    private BigDecimal balance;
    private int selection;
    private Change myChange;
    private String message;
    
    @Inject
    public VendingMachineServiceImpl(VendingMachineDAO vendingMachineDAO) {
        this.vendingMachineDAO = vendingMachineDAO;
        balance = new BigDecimal("0.00");
        selection = 0;
        myChange = null;
        message = null;
    }

    @Override
    public void addMoney(String amount) {
        switch (amount) {
            
            case "quarter":
                balance = balance.add(new BigDecimal("0.25"));
                break;
            
            default:
        }
    }
    @Override
    public void makePurchase() {
        if (selection != 0) {
        	Snack snack = vendingMachineDAO.getSnackById(selection);
            BigDecimal selectionPrice = snack.getPrice();
            if (snack.getQuantity() <= 0) {
                message = "SOLD OUT!!!";
            } else if (balance.compareTo(selectionPrice) < 0) {
                BigDecimal difference = selectionPrice.subtract(balance);
                message = "Please Deposit: $" + difference;
            } else {
                BigDecimal newBalance = balance.subtract(selectionPrice);
                Change change = new Change(newBalance);
                myChange = change;
                balance = new BigDecimal("0.00");
                int newSodaQuantity = snack.getQuantity() - 1;
                snack.setQuantity(newSodaQuantity);
                message = "Thank You!";
            }
        }
    }
    @Override
    public void changeReturn() {
        Change change = new Change(balance);
        myChange = change;
        balance = new BigDecimal("0.00");
        selection = 0;
        message = null;
    }
    
    @Override
    public List<Snack> getSnacks() {
        return vendingMachineDAO.getSnacks();
    }
    @Override
    public Snack getSnackById(int id) {
        return vendingMachineDAO.getSnackById(id);
    }

    @Override
    public BigDecimal getBalance() {
        return balance;
    }
    @Override
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    @Override
    public int getSelection() {
        return selection;
    }
    @Override
    public void setSelection(int Selection) {
        this.selection = Selection;
    }
    @Override
    public Change getChange() {
        return myChange;
    }
    @Override
    public void setMyChange(Change myChange) {
        this.myChange = myChange;
    }      
    @Override
    public String getMessage() {
        return message;
    }
    @Override
    public void setMessage(String message) {
        this.message = message;
    }

	  
}


